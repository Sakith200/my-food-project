<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_POST['action'] === 'add_to_cart') {
    $item_id = $_POST['item_id'];
    $items = [
        1 => ['name' => 'Pizza', 'price' => 1200],
        2 => ['name' => 'Burger', 'price' => 800],
        3 => ['name' => 'Kottu', 'price' => 950],
    ];

    if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

    if (!isset($_SESSION['cart'][$item_id])) {
        $_SESSION['cart'][$item_id] = [
            'id' => $item_id,
            'name' => $items[$item_id]['name'],
            'price' => $items[$item_id]['price'],
            'quantity' => 1
        ];
    } else {
        $_SESSION['cart'][$item_id]['quantity']++;
    }

    echo json_encode(['success' => true, 'message' => 'Item added to cart!']);
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Fast Food</title>
    <script src="script.js"></script>
</head>
<body>
    <h1>SM Fast Food</h1>

    <button onclick="addToCart(1)">Add Pizza</button>
    <button onclick="addToCart(2)">Add Burger</button>
    <button onclick="addToCart(3)">Add Kottu</button>

    <div id="cart-info">Cart: 0 items | Rs. 0</div>
    <script src="script.js"></script>

</body>
</html>
<?php
session_start();

$count = 0;
$total = 0;

if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $count += $item['quantity'];
        $total += $item['quantity'] * $item['price'];
    }
}

echo json_encode(['count' => $count, 'total' => $total]);
